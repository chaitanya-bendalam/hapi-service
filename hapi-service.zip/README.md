# Hapi Service
This is HAPI service Application based on hapi@17.5.1 version.

hapi-service Application
git clone  https://github.com/chaitu0609/hapi-service.git

## Getting started

- Run: npm install
- Run the application: npm start

## Installations

Run "npm install" to install dependency packages.

## How use it
Run "npm start" to run the Application. The application will be running at http://127.0.0.1:1337/

## License

 © Public
